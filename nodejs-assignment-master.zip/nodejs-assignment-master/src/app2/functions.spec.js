var { function5 } = require('./functions')

describe('functions', () => {
    it('function5', async () => {
        expect(true).toBe(true)
    })
})
